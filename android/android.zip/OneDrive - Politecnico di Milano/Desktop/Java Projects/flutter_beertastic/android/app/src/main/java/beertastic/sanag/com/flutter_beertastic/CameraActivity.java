package beertastic.sanag.com.flutter_beertastic;


public class CameraActivity {

}
